#!/usr/bin/env bash
# faer#290: re-measure tensor4all/faer#282 (tiled copy_from_triangular_lower) before vs after, on evo2.
# Declaration (written before any timing): blast-radius.md. Binaries: bin/SHA256SUMS, bin/{before,after}.vars.
#   before = fork 06d8e84c (main just before #282), after = fork 2b87010c (#282 merged); both with harness
#   94fcae3 (= faer-benchmark main f7cec19 + fork range <0.32), upstream faer-v0.24.4 0539947f, oneMKL 2026.2, same lock.
# Starts only after the faer#279 sweep writes DONE; uses that sweep's CPU window (1T 8, 4T 8-11, 8T 8-15).
set -uo pipefail
R=$(cd "$(dirname "$0")" && pwd)
P=/home/shinaoka/work/aocl-bench-extern/fb-94fcae3/benchmarks/scripts/pinned.sh
SWEEP=/home/shinaoka/work/lu-chol-opt/runs/20261107-leaf279/driver.log
export PINNED_RETRIES=8
log=$R/driver.log
say() { echo "$(date -Is) $*" >> "$log"; }

if env | grep -q '^MALLOC_'; then echo "refusing: MALLOC_* set: $(env | grep '^MALLOC_')" >&2; exit 3; fi
mask=$(taskset -pc $$ | sed 's/.*: //')
python3 - "$mask" <<'PY' || { echo "refusing: driver affinity $mask overlaps the measured domain 8-15,24-31" >&2; exit 3; }
import sys
def cpus(s):
    out = set()
    for part in s.split(','):
        a, _, b = part.partition('-'); out |= set(range(int(a), int(b or a) + 1))
    return out
raise SystemExit(1 if cpus(sys.argv[1]) & (set(range(8, 16)) | set(range(24, 32))) else 0)
PY
(cd "$R/bin" && sha256sum -c --quiet SHA256SUMS) || { echo "refusing: binaries changed" >&2; exit 3; }

power() {  # <tag>: every boost / frequency knob the host exposes, read-only
    local f=$R/power-$1.txt
    {
        echo "# $(date -Is) $1"
        echo "global cpufreq/boost=$(cat /sys/devices/system/cpu/cpufreq/boost) (writable by this user: $([[ -w /sys/devices/system/cpu/cpufreq/boost ]] && echo yes || echo no))"
        echo "amd_pstate/status=$(cat /sys/devices/system/cpu/amd_pstate/status 2>/dev/null)"
        for c in $(seq 0 31); do
            d=/sys/devices/system/cpu/cpu$c
            echo "cpu$c policy_boost=$(cat $d/cpufreq/boost 2>/dev/null) governor=$(cat $d/cpufreq/scaling_governor) epp=$(cat $d/cpufreq/energy_performance_preference 2>/dev/null) scaling_max=$(cat $d/cpufreq/scaling_max_freq) cpuinfo_max=$(cat $d/cpufreq/cpuinfo_max_freq) nominal_mhz=$(cat $d/acpi_cppc/nominal_freq 2>/dev/null) highest_perf=$(cat $d/acpi_cppc/highest_perf 2>/dev/null) nominal_perf=$(cat $d/acpi_cppc/nominal_perf 2>/dev/null)"
        done
        echo "platform_profile=$(cat /sys/firmware/acpi/platform_profile 2>/dev/null)"
        echo "kernel log, boost writes since boot:"; journalctl -k -b 2>/dev/null | grep -i 'boost' | tail -5
    } > "$f"
}

: > "$log"
say "driver start, affinity $mask, harness $(cat "$R/bin/harness.rev")"
{
    echo "IDENTITY harness (faer-benchmark) $(cat "$R/bin/harness.rev") = main f7cec19 + fork range <0.32"
    for b in before after; do
        grep -E '^(FAER_FORK_REV|FAER_FORK_VERSION|FAER_FORK_DIRTY|FAER_UPSTREAM_REV|FAER_UPSTREAM_REF|FAER_UPSTREAM_DIRTY|BUILD_ENV|BUILD_FEATURES|BUILD_LOCK_SHA256)=' "$R/bin/$b.vars" | sed "s/^/IDENTITY $b /"
    done
    sed 's/^/IDENTITY sha256 /' "$R/bin/SHA256SUMS"
    git -C /home/shinaoka/work/aocl-bench-extern/t4a-faer diff --stat 06d8e84c 2b87010c -- faer faer-traits faer-macros Cargo.toml Cargo.lock | sed 's/^/IDENTITY measured-path diff before..after: /'
} >> "$log"
CLEAN=(env -u OMP_NUM_THREADS -u OMP_PROC_BIND -u OMP_PLACES -u OMP_DYNAMIC -u OMP_WAIT_POLICY -u GOMP_CPU_AFFINITY
       -u GOMP_SPINCOUNT -u KMP_AFFINITY -u KMP_BLOCKTIME -u MKL_NUM_THREADS -u MKL_DYNAMIC -u MKL_ENABLE_INSTRUCTIONS
       -u MKL_CBWR -u MKL_THREADING_LAYER -u MKL_INTERFACE_LAYER -u MKL_DOMAIN_NUM_THREADS -u OPENBLAS_NUM_THREADS
       -u RAYON_NUM_THREADS -u LD_LIBRARY_PATH -u FAER_LU_LEAF)
for b in before after; do "${CLEAN[@]}" "$R/bin/fbench-$b" info | grep '^vendor\.' | sed "s/^/IDENTITY $b /" >> "$log"; done
cpus() { case $1 in 1) echo 8;; 4) echo 8-11;; 8) echo 8-15;; esac; }
ROWS=faer-fork,faer-upstream,lapack-mkl
# The declared grid (blast-radius.md): three populations per process set.
pop_args() {
    case $1 in
        A) echo "--family cholesky,eigh --n 32,64,96,128,256,512 --dtype f64,c64,f32,c32";;
        B) echo "--family cholesky,eigh --n 255,257,511,513,1024,1536 --dtype f64,c64";;
        C) echo "--family lu,qr_factor,gemm --n 1024 --dtype f64,c64";;
    esac
}

# ---- wait for faer#279's sweep -------------------------------------------------------------------
power pre-wait
w0=$(date +%s); say "waiting for DONE in $SWEEP"
until grep -q '^DONE' "$SWEEP"; do sleep 60; done
w1=$(date +%s); say "sweep DONE seen; waited $(( w1 - w0 ))s"
sleep 30
power start
# Effective clock of the measured CPUs, read from this (observer) side every 5 s: cpuinfo_avg_freq is the
# kernel's APERF/MPERF average from the tick, so reading it sends nothing to the measured CPUs.
( while :; do printf "%s" "$(date +%s)"; for c in $(seq 8 15); do printf "\t%s" "$(cat /sys/devices/system/cpu/cpu$c/cpufreq/cpuinfo_avg_freq 2>/dev/null)"; done; echo; sleep 5; done ) > "$R/freq.tsv" &
sampler=$!
trap 'kill $sampler 2>/dev/null' EXIT
say "MEASUREMENT START (first command on CPUs 8-15 follows)"

# ---- correctness first: verify every population, both binaries, every budget ----------------------
mkdir -p "$R/verify" "$R/csv"
for T in 1 4 8; do for b in before after; do for pop in A B C; do
    out=$R/verify/$b-$pop-t$T
    cmd=("${CLEAN[@]}" "$R/bin/fbench-$b" verify --threads $T $(pop_args $pop) --rows $ROWS --csv $out.csv)
    say "CMD taskset -c $(cpus $T) ${cmd[*]}"
    taskset -c "$(cpus $T)" "${cmd[@]}" > $out.out 2>&1; rc=$?
    say "verify $b $pop T=$T exit $rc"
    [[ $rc == 0 ]] || { say "verify failed; nothing timed"; echo ABORTED >> "$log"; exit 1; }
done; done; done

# ---- timing: passes x budgets x binaries, interleaved ---------------------------------------------
for p in 0 1 2; do
    for T in 1 4 8; do
        if (( p % 2 == 0 )); then bins="before after"; else bins="after before"; fi
        for b in $bins; do
            for pop in A B C; do
                out=$R/csv/$pop-$b-t$T-run$p
                cmd=("${CLEAN[@]}" "$R/bin/fbench-$b" run --threads $T $(pop_args $pop) --rows $ROWS
                     --reps 5 --prime-ms 250 --statistic median --rotate-rows $p --csv $out.csv)
                say "CMD PINNED_CSV=$out.csv bash $P $(cpus $T) -- ${cmd[*]}"
                s=$(date +%s)
                PINNED_CSV=$out.csv bash "$P" "$(cpus $T)" -- "${cmd[@]}" > $out.out 2> $out.guard; rc=$?
                say "timed $pop $b T=$T pass $p exit $rc wall $(( $(date +%s) - s ))s"
            done
        done
    done
done
power end
say "MEASUREMENT END"
echo DONE >> "$log"
