#!/usr/bin/env bash
# The fork's own gate at the merged revision (adoption-protocol: cargo test -p <fork> --lib, plus the change's tests).
cd ~/work/aocl-bench-extern/t4a-faer || exit 1
L=~/work/aocl-bench-runs/20261107-290/gates
echo "rev $(git rev-parse HEAD) dirty=$(git status --porcelain | wc -l) start $(date -Is)" > $L/cargo-test-lib-2b87010c.log
CARGO_BUILD_JOBS=8 RUST_TEST_THREADS=8 cargo test -p t4a-faer --lib >> $L/cargo-test-lib-2b87010c.log 2>&1
echo "exit $? end $(date -Is)" >> $L/cargo-test-lib-2b87010c.log
