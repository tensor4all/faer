# faer#290: the acceptance run for #282 (tiled triangular copy), 2026-11-07/08 on evo2

Raw evidence for the run summarized in
[`docs/worklogs/2026-11-07-tiled-triangular-copy-acceptance.md`](../../../2026-11-07-tiled-triangular-copy-acceptance.md).
Host: evo2 (`EVO-X2`), AMD Ryzen AI MAX+ 395, 32 logical CPUs in four L3 domains (8-15 and 24-31 are the
measured domain and its siblings), boost switch not writable by this user.

## Identity

| item | value |
| --- | --- |
| `before` = fork `06d8e84c3e31e824dffe9fb1fc0945c7d90db1d0` | `main` just before #282, `FAER_FORK_DIRTY=false`, version 0.31.0 |
| `after` = fork `2b87010cb82efbe0a90eceeb51931a833e1de8e6` | #282 merged, `FAER_FORK_DIRTY=false`, version 0.31.0 |
| harness | faer-benchmark `94fcae3a1922421c9eb9119cee27cabdf8783958` = `main` `f7cec19` + the fork range `<0.32` |
| upstream row | faer `0539947ffb757a739d7e703a7d2fa0c792a909c1`, `faer-v0.24.4`, clean |
| vendor row | oneMKL 2026.2, shared linkage, `MKL_THREADING_LIB=libiomp5.so` |
| lock | `01c7e22c82e4af1cfbe301c51037f522ae2f17e2380262b94e4592457f83546a` |
| measured-path diff, `before..after` | `faer/src/linalg/mod.rs` +133, `faer/src/mat/matmut.rs` +10/-1; nothing else |
| window | 2026-11-07 16:17:24 +09:00 to 2026-11-08 04:21:29 +09:00 (verification 16:17-18:54, timing 18:54-04:21) |
| CPUs | 1T on CPU 8, 4T on 8-11, 8T on 8-15 (one L3 domain); the driver ran on 0-7, 16-23 |

The two `fbench` binaries are not in this archive (28 MiB). `bin/SHA256SUMS` pins them, and they were
re-checked against it after the run:

```
fbench-before: OK
fbench-after: OK
sha256 5eacaa9dd286604871d4ba0650d730d35f7114400447615985e086128413706f  fbench-before
sha256 deb685ba22d760bb07c2e77295426c9fb5fe698bff8b48d9ba9b0794b8c5fbb4  fbench-after
```

## Files

| path | what it is |
| --- | --- |
| `blast-radius.md` | the grid and the target/guard/collateral split, written before any timing |
| `run.sh` | the driver: it refuses to start if `MALLOC_*` is set, if its own affinity touches the measured domain, or if a binary hash moved |
| `driver.log` | identity, one `CMD` line per process, 18 `verify ... exit 0`, 54 `timed ... exit 0`, wait for and end of the window |
| `csv/<set>-<binary>-t<T>-run<p>.csv` | 54 timed processes (3 sets x 2 binaries x 3 thread counts x 3 passes); one row per cell and row identity |
| `csv/*.guard`, `csv/*.out` | the idle guard's verdict per process (all admitted on attempt 1) and the harness stdout |
| `verify/<binary>-<set>-t<T>.{csv,out}` | `fbench verify` for every population, binary and budget: 18 of 18 clean |
| `power-*.txt` | every cpufreq knob the host exposes, before the wait, at start and at end, plus the kernel's boost log |
| `freq.tsv` | the effective clock of CPUs 8-15, sampled from the observer side every 5 s during the whole run |
| `census/` | the instrumented-copy census behind the blast radius: which timed calls reach the changed function and which take the tiled branch |
| `gates/` | `cargo test -p t4a-faer --lib` at `2b87010c` (685 passed, 0 failed) |
| `summary.md` | the run's own summarizer output (per cell, with the same-process ratios) |
| `cells.csv` | the reduction this record's tables are read from: one row per cell, median of the three process medians per binary, after/before ratio, and the two between-start spreads |
| `analyze-290.py` | `cells.csv` and every table in the record, from `csv/*.csv` only: `python3 -I analyze-290.py` |
| `summarize.py` | the summarizer that produced `summary.md` |

Reading a ratio: `< 1` means the `after` binary was faster. `cells.csv` has no summary of its own in it;
it is rebuilt from the 54 process CSVs, so any number here can be re-derived.
