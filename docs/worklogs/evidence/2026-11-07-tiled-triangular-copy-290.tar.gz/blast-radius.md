# faer#290 re-measurement of #282: blast radius, declared before any timing

Written 2026-11-07, before the run; not widened after the numbers are seen.

Change: tensor4all/faer#282, merged as `2b87010cb82efbe0a90eceeb51931a833e1de8e6`; its parent on main is
`06d8e84c3e31e824dffe9fb1fc0945c7d90db1d0`. Code diff between the two: `faer/src/linalg/mod.rs` (+133,
`copy_lower_across_layouts`, `copy_across_layouts_block` reuse) and `faer/src/mat/matmut.rs` (+9/-1, the call in
`MatMut::copy_from_triangular_lower`); `Cargo.lock` and every other measured path identical.

## Reading the changed path

`copy_from_triangular_lower` is a shared helper (adoption-protocol: "every family that copies or owns a
matrix"). Its static callers in the fork: `Llt::new`, `Ldlt::new`, `Lblt::new` (`solvers.rs:988,1036,1092`),
the self-adjoint EVD (`evd/mod.rs:359`), the triangular matmul's operand copy (`matmul/triangular.rs:48`), the
generalized self-adjoint EVD (`solvers.rs:634`), LQ, sparse Cholesky, and through `copy_from_triangular_upper`
QR (`qr/no_pivoting/factor.rs:338,497`), `PartialPivLu` (`solvers.rs:1167`) and others.

## What the harness's timed calls actually reach (census, not timing)

Instrumented copy of the fork at `2b87010c` (one `eprintln` per call of `copy_from_triangular_lower`, logging
shape, strides and whether the tiled branch is taken), harness `94fcae3`, every suite family, f64/c64/f32/c32,
both orders, n = 96, 1024x64, 64x1024 (and 1024 for cholesky/eigh), T = 1 and 4, run once at `--reps 1` and once
at `--reps 3`: a count that scales with `--reps` is inside the clock. Raw: `census/census.tsv`, `census/build.log`.

| family | reaches the changed function inside the clock | takes the new tiled branch |
|---|---|---|
| `cholesky` owning (`Llt::new`) | yes, once per call | **yes, C order only** (row-major source into the column-major factor); F order takes the unchanged contiguous branch |
| `cholesky` `in_place` | no | no |
| `eigh` owning and `in_place` | yes, once per call (`evd/mod.rs:359`) | **yes, C order only** |
| `qr_factor`, `qr`, `svd_values`, `svd_thin`, `householder_apply` | yes (internal 16x16 / 12x12 blocks) | never: the destination is not column-major; the change adds one stride test to these calls |
| `lu`, `full_piv_lu` | only outside the clock (count does not scale with reps) | no |
| `gemm`, `solve`, `triangular_solve`, `eig`, `upgrade_factor` | no | no |

The tiled branch also requires `m * n >= 64 * 64` (`row_major_copy_pays`), so n = 32 is below the floor and
is a guard on the unchanged path.

## Declared grid

- **Target families**: `cholesky`, `eigh`, every declared square shape and dtype, both orders, T = 1, 4, 8:
  - faer-kernels `linalg-small` + `linalg-mid`: n = 32, 64, 96, 128, 256, 512; f64, c64, f32, c32.
  - faer-kernels-large `linalg-boundary` + `linalg-large`: n = 255, 257, 511, 513, 1024, 1536; f64, c64
    (the large suite declares 4T/8T only; 1T is added here because #290 asks for it).
  - `linalg-big` (2048-4096, adoption-only) is not measured.
- **Target cells** (where the change claims an improvement): C order, `faer-fork` owning `cholesky` and
  both `eigh` ops, n >= 64.
- **Guard cells, same processes**: the same families in F order; the `cholesky` `in_place` op; n = 32;
  the `faer-upstream` rows (unchanged code in both binaries: the protocol's machine-state control); the
  `lapack-mkl` row (second machine control, independent of faer).
- **Collateral control families** (separate process right after, same CPU set): `lu`, `qr_factor`, `gemm`
  at 1024, f64 and c64, both orders, T = 1, 4, 8. `qr_factor` reaches the changed function on its unchanged
  branch; `lu` and `gemm` do not reach it in the clock.

## Settings

`--reps 5 --prime-ms 250 --statistic median`, rows `faer-fork,faer-upstream,lapack-mkl`, three process sets with
`--rotate-rows 0,1,2` (every row in every position once: the protocol's `--aa 3`), `pinned.sh` with
`PINNED_RETRIES=8`, CPU sets 1T -> 8, 4T -> 8-11, 8T -> 8-15 (the faer#279 sweep's window; L3 domain 8-15,24-31),
driver on 0-7,16-23. Before and after binaries alternate within every (pass, T), order flipped by pass; 1T, 4T
and 8T are interleaved inside each pass. Same harness, upstream, MKL and lock for both binaries.

Boost: not writable (see `power-*.txt`); the run records the switch states and the measured CPUs' effective
clock throughout (`freq.tsv`).
