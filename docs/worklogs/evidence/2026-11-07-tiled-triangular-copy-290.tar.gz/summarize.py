"""Summarise run.sh's CSVs for faer#290. Usage: python3 -I summarize.py <run dir>

Statistic: every process reports, per cell and row op, the median of its 5 timed calls (`total_ms`). A cell's
value per binary is the median of its three process medians; its between-start spread is max/min of the three.
after/before is the ratio of those values. The protocol's tests (docs/protocol-v2-baseline.md, section 5):
  - target improves: after/before < 1/spread_before (leaves the baseline's between-start band), direction consistent;
  - guard: no fork cell slower than spread_before (after/before > spread_before is listed);
  - control: the faer-upstream row (identical code in both binaries) reproduces the baseline: median of its per-cell
    after/before within 2% of 1. lapack-mkl is reported the same way as a second machine control.
Same-process control: fork/upstream of the same op in the same process, after vs before; it cancels a machine that
was faster or slower for the whole process.
"""
import csv
import glob
import os
import re
import statistics as st
import sys
from collections import defaultdict

R = sys.argv[1]
ORDER = {"f": "col", "c": "row"}
NPASS = int(os.environ.get("NPASS", "3"))  # 3 for the real run; the dry run had 2


def load():
    cells = defaultdict(lambda: defaultdict(dict))  # key -> bin -> pass -> ms
    for path in sorted(glob.glob(os.path.join(R, "csv", "*-t*-run*.csv"))):
        m = re.search(r"/([ABC])-(before|after)-t(\d+)-run(\d)\.csv$", path)
        _, b, _, p = m.groups()
        for r in csv.DictReader(open(path)):
            if r["status"] != "ok" or not r["total_ms"]:
                continue
            shape = "x".join(x for x in (r["m"], r["k"], r["n"]) if x) if r["family"] == "gemm" else (
                r["m"] if r["m"] == r["n"] else f"{r['m']}x{r['n']}")
            key = (r["family"], r["dtype"], r["order"], shape, int(r["threads"]), r["row"], r["note"] or "owning")
            cells[key][b][int(p)] = float(r["total_ms"])
    return cells


def med(d):
    return st.median(d.values()) if d else None


def spread(d):
    return max(d.values()) / min(d.values()) if len(d) > 1 else None


def size(shape):
    return int(shape.split("x")[0])


def fmt(x, d=3):
    return "-" if x is None else f"{x:.{d}f}"


def identity():
    print("**Identity** (from `driver.log`, written before the first measurement):\n")
    for l in open(os.path.join(R, "driver.log")):
        if l.startswith("IDENTITY "):
            print(f"- `{l[len('IDENTITY '):].strip()}`")
    for l in open(os.path.join(R, "driver.log")):
        if re.search(r"waited|MEASUREMENT (START|END)", l):
            print(f"- `{l.strip()}`")
    print()


def is_target(k):
    fam, dt, o, shape, t, row, note = k
    return row == "faer-fork" and o == "c" and size(shape) >= 64 and (
        (fam == "cholesky" and note == "owning") or fam == "eigh")


def main():
    cells = load()
    identity()
    full = {k: v for k, v in cells.items() if len(v["before"]) == NPASS and len(v["after"]) == NPASS}
    print(f"cells with all processes on both binaries: {len(full)} of {len(cells)}\n")

    def ratio(k):
        return med(full[k]["after"]) / med(full[k]["before"])

    def inproc(k):
        """fork/upstream in each process, after over before (median of three per binary)."""
        u = (k[0], k[1], k[2], k[3], k[4], "faer-upstream", k[6])
        if u not in full:
            return None
        r = {b: st.median(full[k][b][p] / full[u][b][p] for p in range(NPASS)) for b in ("before", "after")}
        return r["after"] / r["before"]

    # ---- controls ----
    print("## Machine-state controls (rows whose code is identical in both binaries)\n")
    print("| row | cells | median after/before | min | max | cells outside +-10% |")
    print("|---|---|---|---|---|---|")
    for row in ("faer-upstream", "lapack-mkl"):
        rs = [ratio(k) for k in full if k[5] == row]
        print(f"| {row} | {len(rs)} | **{fmt(st.median(rs), 4)}** | {fmt(min(rs))} | {fmt(max(rs))} "
              f"| {sum(1 for r in rs if abs(r - 1) > 0.10)} |")
    for row in ("faer-upstream", "lapack-mkl"):
        print(f"\nPer budget, {row}: " + ", ".join(
            f"{t}T {fmt(st.median([ratio(k) for k in full if k[5] == row and k[4] == t]), 4)}" for t in (1, 4, 8)))
    print()

    # ---- target ----
    print("## Target cells: row-major `cholesky` (owning, `Llt::new`) and `eigh` (both ops), n >= 64, fork row\n")
    print("| family | op | dtype | n | T | before ms (spread) | after ms (spread) | **after/before** | band 1/spread | "
          "same-process fork/upstream, after/before | upstream after/before | verdict |")
    print("|---|---|---|---|---|---|---|---|---|---|---|---|")
    verdicts = defaultdict(int)
    for k in sorted((k for k in full if is_target(k)), key=lambda k: (k[0], k[6], k[1], size(k[3]), k[4])):
        b, a = full[k]["before"], full[k]["after"]
        s = spread(b)
        r = ratio(k)
        u = (k[0], k[1], k[2], k[3], k[4], "faer-upstream", k[6])
        v = "improved" if r < 1 / s else ("regressed" if r > s else "within band")
        verdicts[v] += 1
        print(f"| {k[0]} | {k[6]} | {k[1]} | {k[3]} | {k[4]} | {fmt(med(b))} ({fmt(s)}) | {fmt(med(a))} ({fmt(spread(a))}) "
              f"| **{fmt(r)}** | {fmt(1 / s)} | {fmt(inproc(k))} | {fmt(ratio(u)) if u in full else '-'} | {v} |")
    print(f"\nTarget verdicts: {dict(verdicts)}\n")

    # ---- guard ----
    guard = [k for k in full if k[5] == "faer-fork" and not is_target(k)]
    print("## Guard cells (fork row, everything not a target: column-major, `cholesky` in_place, n = 32, "
          "collateral `lu`/`qr_factor`/`gemm`)\n")
    rs = [ratio(k) for k in guard]
    worse = [k for k in guard if ratio(k) > spread(full[k]["before"])]
    print(f"{len(guard)} cells; median after/before {fmt(st.median(rs), 4)}; slower than the baseline's own spread: "
          f"{len(worse)}\n")
    print("| family | op | dtype | order | shape | T | before ms (spread) | after ms (spread) | after/before | "
          "same-process fork/upstream, after/before |")
    print("|---|---|---|---|---|---|---|---|---|---|")
    for k in sorted(guard, key=lambda k: -ratio(k))[:15]:
        print(f"| {k[0]} | {k[6]} | {k[1]} | {ORDER[k[2]]} | {k[3]} | {k[4]} | {fmt(med(full[k]['before']))} "
              f"({fmt(spread(full[k]['before']))}) | {fmt(med(full[k]['after']))} ({fmt(spread(full[k]['after']))}) "
              f"| {fmt(ratio(k))} | {fmt(inproc(k))} |")
    print("\n(the fifteen largest after/before among the guard cells)\n")
    print("Collateral families, per budget (median after/before over dtypes, orders and ops): " + "; ".join(
        f"{fam} " + ", ".join(f"{t}T {fmt(st.median([ratio(k) for k in guard if k[0] == fam and k[4] == t]))}"
                              for t in (1, 4, 8)) for fam in ("lu", "qr_factor", "gemm")))
    print()

    # ---- clocks ----
    print("## Effective clock of the measured CPUs during the run (`freq.tsv`, cpuinfo_avg_freq every 5 s)\n")
    rows = [list(map(int, l.split("\t")[1:])) for l in open(os.path.join(R, "freq.tsv")) if l.count("\t") == 8]
    print("| CPU | samples | loaded samples (> 2.1 GHz) | median loaded MHz | max MHz |")
    print("|---|---|---|---|---|")
    for i, c in enumerate(range(8, 16)):
        xs = [r[i] for r in rows if r[i]]
        ld = [x for x in xs if x > 2_100_000]
        print(f"| {c} | {len(xs)} | {len(ld)} | {fmt(st.median(ld) / 1000, 0) if ld else '-'} | "
              f"{fmt(max(xs) / 1000, 0) if xs else '-'} |")
    print()

    # ---- guard admissions ----
    att = defaultdict(int)
    for g in glob.glob(os.path.join(R, "csv", "*.guard")):
        m = re.findall(r"idle before and after \(attempt (\d+)\)", open(g).read())
        att[int(m[-1]) if m else "none"] += 1
    print(f"Idle-guard admission attempt per process (1 = admitted first time): {dict(sorted(att.items(), key=str))}")


if __name__ == "__main__":
    main()
