"""faer#290: reduce the 54 timed CSVs to per-cell medians and the tables quoted in the record.

Cell key: (bucket, threads, family, dtype, order, m, n, k, batch, row). Per binary the three process
medians (passes) are reduced with a median; the between-start spread is max/min of those three.
No summary file is read: only csv/*.csv.
"""
import csv, glob, os, re, statistics as st
from collections import defaultdict
import sys

R = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(R, "csv")
pat = re.compile(r"^([ABC])-(after|before)-t(\d+)-run(\d+)\.csv$")

cells = defaultdict(lambda: {"before": [], "after": []})
files = 0
for path in sorted(glob.glob(os.path.join(D, "*.csv"))):
    m = pat.match(os.path.basename(path))
    if not m:
        continue
    files += 1
    kind = m.group(2)
    with open(path, newline="") as fh:
        for row in csv.DictReader(fh):
            if (row.get("status") or "") != "ok":
                continue
            try:
                us = float(row["per_item_us"])
            except (KeyError, TypeError, ValueError):
                continue
            if us <= 0:
                continue
            note = (row.get("note") or "").strip()
            if "skipped" in note:
                continue
            op = "in_place" if note == "in_place" else "owning"
            key = (m.group(1), int(m.group(3)), row["family"], row["dtype"], row["order"],
                   int(row["m"]), int(row["n"]), op, row["batch"], row["row"])
            cells[key][kind].append(us)

out = []
for key, v in sorted(cells.items()):
    if len(v["before"]) < 3 or len(v["after"]) < 3:
        continue
    b, a = st.median(v["before"]), st.median(v["after"])
    out.append(dict(bucket=key[0], threads=key[1], family=key[2], dtype=key[3], order=key[4],
                    m=key[5], n=key[6], op=key[7], batch=key[8], row=key[9],
                    before_us=b, after_us=a, ratio=a / b,
                    before_spread=max(v["before"]) / min(v["before"]),
                    after_spread=max(v["after"]) / min(v["after"]),
                    passes_before=len(v["before"]), passes_after=len(v["after"])))

with open(os.path.join(R, "cells.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0].keys()))
    w.writeheader()
    for r in out:
        r = dict(r)
        r["before_us"] = f"{r['before_us']:.6f}"
        r["after_us"] = f"{r['after_us']:.6f}"
        r["ratio"] = f"{r['ratio']:.6f}"
        r["before_spread"] = f"{r['before_spread']:.6f}"
        r["after_spread"] = f"{r['after_spread']:.6f}"
        w.writerow(r)

print(f"# files={files} cells={len(out)}")


def sel(**kw):
    return [r for r in out if all(r[k] == v for k, v in kw.items())]


def med(xs):
    return st.median(xs) if xs else float("nan")


# ---- controls: rows whose code is identical in both binaries ----
print("\n## controls\n")
print("| row | cells | median after/before | p10 | p90 | per T |")
print("|---|---|---|---|---|---|")
for row in ("faer-upstream", "lapack-mkl"):
    rs = [r["ratio"] for r in out if r["row"] == row]
    s = sorted(rs)
    per = ", ".join(
        f"{t}T {med([r['ratio'] for r in out if r['row'] == row and r['threads'] == t]):.4f}"
        for t in (1, 4, 8))
    print(f"| `{row}` | {len(rs)} | **{med(rs):.4f}** | {s[int(.1*len(s))]:.4f} | {s[int(.9*len(s))]:.4f} | {per} |")

# ---- collateral families, fork row ----
print("\n## collateral (fork row, population C)\n")
print("| family | cells | median after/before | 1T | 4T | 8T |")
print("|---|---|---|---|---|---|")
for fam in ("lu", "qr_factor", "gemm"):
    rs = sel(family=fam, row="faer-fork")
    per = " | ".join(f"{med([r['ratio'] for r in rs if r['threads'] == t]):.3f}" for t in (1, 4, 8))
    print(f"| `{fam}` | {len(rs)} | **{med([r['ratio'] for r in rs]):.3f}** | {per} |")

# ---- target: row-major cholesky owning, fork row ----
print("\n## cholesky owning, order=c (the target path), fork row: after/before\n")
dts = ["f64", "c64", "f32", "c32"]
ns = sorted({r["n"] for r in sel(family="cholesky", row="faer-fork", order="c")})
print("| dtype | T | " + " | ".join(str(n) for n in ns) + " |")
print("|---" * (len(ns) + 2) + "|")
for dt in dts:
    for t in (1, 4, 8):
        vals = []
        for n in ns:
            rs = [r["ratio"] for r in sel(family="cholesky", row="faer-fork", order="c", dtype=dt,
                                          n=n, threads=t, op="owning")]
            vals.append(f"{rs[0]:.2f}" if rs else "")
        if all(v == "" for v in vals):
            continue
        print(f"| {dt} | {t} | " + " | ".join(vals) + " |")

# ---- guard: column-major (order=f) same cells ----
print("\n## cholesky owning, order=f (unchanged contiguous branch), fork row: after/before\n")
print("| dtype | T | " + " | ".join(str(n) for n in ns) + " |")
print("|---" * (len(ns) + 2) + "|")
for dt in dts:
    for t in (1, 4, 8):
        vals = []
        for n in ns:
            rs = [r["ratio"] for r in sel(family="cholesky", row="faer-fork", order="f", dtype=dt,
                                          n=n, threads=t, op="owning")]
            vals.append(f"{rs[0]:.2f}" if rs else "")
        if all(v == "" for v in vals):
            continue
        print(f"| {dt} | {t} | " + " | ".join(vals) + " |")

# ---- eigh, row-major ----
print("\n## eigh owning, order=c, fork row: after/before (median over T, both ops)\n")
print("| dtype | " + " | ".join(str(n) for n in ns) + " |")
print("|---" * (len(ns) + 1) + "|")
for dt in dts:
    vals = []
    for n in ns:
        rs = [r["ratio"] for r in sel(family="eigh", row="faer-fork", order="c", dtype=dt, n=n, op="owning")]
        vals.append(f"{med(rs):.3f}" if rs else "")
    if all(v == "" for v in vals):
        continue
    print(f"| {dt} | " + " | ".join(vals) + " |")

# ---- the #282 slide cell ----
print("\n## #282's own cell (1024, f64, 8T, row-major cholesky owning)\n")
for r in sel(family="cholesky", row="faer-fork", order="c", dtype="f64", n=1024, threads=8, op="owning"):
    print(f"- fork: {r['before_us']/1000:.3f} -> {r['after_us']/1000:.3f} ms, ratio {r['ratio']:.3f}, "
          f"spread before {r['before_spread']:.3f} after {r['after_spread']:.3f}")
for r in sel(family="cholesky", row="faer-upstream", order="c", dtype="f64", n=1024, threads=8, op="owning"):
    print(f"- upstream (same process): {r['before_us']/1000:.3f} -> {r['after_us']/1000:.3f} ms, ratio {r['ratio']:.3f}")

# ---- guard regressions outside the copy path ----
print("\n## cholesky in_place (never calls the changed function), row-major, fork row: after/before\n")
for dt in dts:
    cells_dt = [r for r in sel(family="cholesky", row="faer-fork", order="c", dtype=dt) if r["op"] == "in_place"]
    if not cells_dt:
        continue
    worst = max(cells_dt, key=lambda r: r["ratio"])
    nsd = sorted({r["n"] for r in cells_dt})
    vals = []
    for n in nsd:
        rs = [r["ratio"] for r in cells_dt if r["n"] == n]
        vals.append(f"{med(rs):.2f}")
    print(f"| {dt} | " + " | ".join(f"{n}:{v}" for n, v in zip(nsd, vals)) + f" | worst {worst['ratio']:.2f} ({worst['n']}, {worst['threads']}T)")

# ---- summary of the target set against the spread ----
print("\n## target cells (row-major cholesky owning + eigh, n >= 64, fork row), counted\n")
tgt = [r for r in out if r["row"] == "faer-fork" and r["family"] in ("cholesky", "eigh")
       and r["order"] == "c" and r["n"] >= 64
       and (r["op"] == "owning" if r["family"] == "cholesky" else True)]
slower = [r for r in tgt if r["ratio"] > max(1.0 + 0.0, r["before_spread"])]
faster = [r for r in tgt if r["ratio"] < 1 / r["before_spread"]]
print(f"- cells: {len(tgt)}; faster than the before spread: {len(faster)}; slower than it: {len(slower)}; "
      f"within it: {len(tgt)-len(faster)-len(slower)}")
print(f"- median ratio {med([r['ratio'] for r in tgt]):.3f}")
print(f"- slower-by-n: {sorted({(r['n']) for r in slower})}")
print(f"- faster-by-n: {sorted({(r['n']) for r in faster})}")
