#!/bin/bash
# One measurement session: faer at both revisions (1T and 6T) and the Accelerate reference.
# Appends one line per cell to stdout; a cell that fails is recorded as FAILED and makes the
# script exit non-zero, so an empty or partial record cannot pass for a complete session.
#
#   H_BIN=<main binary>  O_BIN=<325e482 binary>  A_BIN=<accel>  bash sweep.sh <label> >> results.txt
#
# The defaults are the paths on the machine that produced this record; README.txt says how to build
# the two arms so these names exist.
set -uo pipefail
H_BIN=${H_BIN:-/tmp/faer186-harness/target/release/faer186-harness}
O_BIN=${O_BIN:-/tmp/faer186-harness-325/target/release/faer186-harness-325}
A_BIN=${A_BIN:-/tmp/faer186-harness/accel}
REPS=${REPS:-4}
s=${1:-0}
fail=0

# Preflight: all three arms must be executable before any cell runs. Without this, one missing arm
# would produce a session with holes in it, which reads like a complete one.
missing=0
for b in "$H_BIN" "$O_BIN" "$A_BIN"; do
	if [ ! -x "$b" ]; then
		echo "sweep.sh: not executable: $b" >&2
		missing=1
	fi
done
if [ $missing -ne 0 ]; then
	echo "sweep.sh: refusing to start" >&2
	exit 2
fi

# Runs one cell and prints `arm best ...` on success, `arm FAILED ...` on any other outcome.
# A non-zero exit and a run with no `best` line are failures too: neither may be recorded as a
# measurement.
cell() {
	local arm=$1 bin=$2 fam=$3 n=$4
	shift 4
	local out rc
	out=$("$bin" "$fam" "$n" "$@" 2>&1)
	rc=$?
	if [ $rc -ne 0 ] || ! grep -q '^best ' <<<"$out"; then
		printf '%s  FAILED fam=%s n=%s args=%s rc=%s first=%s\n' \
			"$arm" "$fam" "$n" "$*" "$rc" "$(head -1 <<<"$out")"
		fail=1
		return
	fi
	printf '%s  %s\n' "$arm" "$(grep '^best ' <<<"$out")"
}

echo "## session $s start $(date -u +%FT%TZ) load=$(sysctl -n vm.loadavg | tr -d '{}' | xargs)"
for f in gemm_f64 gemm_c64 lu cholesky qr; do
	cell faer_head_1t "$H_BIN" "$f" 2048 1 "$REPS"
	cell faer_head_6t "$H_BIN" "$f" 2048 6 "$REPS"
	cell faer_325_1t "$O_BIN" "$f" 2048 1 "$REPS"
	cell faer_325_6t "$O_BIN" "$f" 2048 6 "$REPS"
	cell accel_1t "$A_BIN" "$f" 2048 "$REPS"
done
cell faer_head_1t "$H_BIN" gemv 4096 1 "$REPS"
cell faer_325_1t "$O_BIN" gemv 4096 1 "$REPS"
cell accel_1t "$A_BIN" gemv 4096 "$REPS"
echo "## session $s end $(date -u +%FT%TZ) load=$(sysctl -n vm.loadavg | tr -d '{}' | xargs) failed=$fail"
exit "$fail"
