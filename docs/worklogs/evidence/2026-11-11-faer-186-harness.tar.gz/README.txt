tensor4all/faer#186 — harness that produced docs/worklogs/2026-11-11-aarch64-m5-reproduction.md

  Cargo.lock   the dependency resolution the numbers were measured with, for arm 1 (origin/main).
  Cargo.lock-325  the same for arm 2 (325e482): it pins `gemm` 0.19.0, `gemm-common` 0.19.0 and
               `threadteam` 0.3.0, where arm 1 pins `t4a-gemm` 0.20.1, `t4a-gemm-common` 0.20.4 and
               `threadteam` 0.5.1 — the whole revision gap in one file.
  src/main.rs  faer side. One family per process:
               cargo run --release -- <gemm_f64|gemm_c64|lu|cholesky|qr|gemv> <n> <threads> <reps>
               threads 1 = Par::Seq, N>1 = faer::team::with_team(N, ..).
               Prints one line per repetition (real/user/sys) plus a best-of line.
  accel.c      Accelerate reference, single threaded:
               cc -O2 -o accel accel.c -framework Accelerate
               ./accel <family> <n> <reps>        (dgemm/zgemm/dgetrf/dpotrf/dgeqrf/dgemv)
  sweep.sh     one recording session over every arm (faer at both revisions, 1T and 6T, plus
               Accelerate), one line per cell. It refuses to start (exit 2) when an arm is not
               executable, and records a cell as FAILED (exit 1) when a run fails or prints no
               `best` line: a partial session cannot be mistaken for a complete one.
  width-sweep.sh  the 6/12/14/18 participant scan behind the worklog's sweep table (a scan, 3 reps).
  results.txt  the three sessions behind the grid tables, with the load average at the start and end
               of each.
  width-sweep.txt   the two recorded width-sweep passes, same load labelling.
  accel-cholesky.txt  six consecutive Accelerate `dpotrf_` passes, the only reference cell with no
               settled value, and accel-cholesky-newlapack.txt the same four passes for the same file
               built with `-DACCELERATE_NEW_LAPACK`.

The two faer arms are two copies of this directory that differ in two lines of Cargo.toml. The
second copy keeps its own binary name so both can exist at once, and sweep.sh's defaults name exactly
those paths:

  # arm 1: origin/main 5c2f4b70
  cp -R . /tmp/faer186-harness
  sed -i '' 's|/path/to/faer-186/faer|/Users/you/faer-186/faer|' /tmp/faer186-harness/Cargo.toml
  # arm 2: 325e482, the revision #186 measured
  cp -R . /tmp/faer186-harness-325
  sed -i '' 's|/path/to/faer-186/faer|/Users/you/faer-325/faer|' /tmp/faer186-harness-325/Cargo.toml
  sed -i '' 's|^name = "faer186-harness"|name = "faer186-harness-325"|' /tmp/faer186-harness-325/Cargo.toml
  cp /tmp/faer186-harness-325/Cargo.lock-325 /tmp/faer186-harness-325/Cargo.lock

  (cd /tmp/faer186-harness && cargo build --release --locked)      # target/release/faer186-harness
  (cd /tmp/faer186-harness-325 && cargo build --release --locked)  # target/release/faer186-harness-325

`--locked` matters: `Cargo.toml` carries ranges (`dyn-stack = "0.13"`, and faer's own manifest ranges
for `gemm`, `threadteam`, `sysctl`), so a run without the lockfile can resolve different versions from
the ones these numbers were measured with, and nothing in the output would say so.
  cc -O2 -o /tmp/faer186-harness/accel accel.c -framework Accelerate

then, from anywhere:

  H_BIN=/tmp/faer186-harness/target/release/faer186-harness \
  O_BIN=/tmp/faer186-harness-325/target/release/faer186-harness-325 \
  A_BIN=/tmp/faer186-harness/accel  bash sweep.sh 1 >> results.txt

Work counts: GEMM 2mnk, complex GEMM 8mnk, LU 2/3n^3, Cholesky 1/3n^3, QR 4/3n^3, GEMV in matrix
elements. Measured on an Apple M5 Max, macOS 26.7.2, rustc 1.96.0, release build, no CPU pinning.
