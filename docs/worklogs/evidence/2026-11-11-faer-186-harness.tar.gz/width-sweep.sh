#!/bin/bash
# The width scan behind the worklog's sweep table and the GEMV/lu checks: one pass, 3 reps per
# cell, `main` only. This is a scan, not a paired comparison, and it is recorded with the load
# average because that is what it is worth.
#
#   H_BIN=<main binary>  bash width-sweep.sh > width-sweep.txt
set -uo pipefail
H_BIN=${H_BIN:-/tmp/faer186-harness/target/release/faer186-harness}
REPS=${REPS:-3}
[ -x "$H_BIN" ] || { echo "width-sweep.sh: not executable: $H_BIN" >&2; exit 2; }
echo "## width sweep start $(date -u +%FT%TZ) load=$(sysctl -n vm.loadavg | tr -d '{}' | xargs)"
for f in gemm_f64 gemm_c64 lu cholesky qr; do
	for t in 6 12 14 18; do
		out=$("$H_BIN" "$f" 2048 "$t" "$REPS" 2>&1) || { echo "$f t=$t FAILED"; exit 1; }
		grep '^best ' <<<"$out" || { echo "$f t=$t FAILED"; exit 1; }
	done
done
echo "## width sweep end $(date -u +%FT%TZ) load=$(sysctl -n vm.loadavg | tr -d '{}' | xargs)"
