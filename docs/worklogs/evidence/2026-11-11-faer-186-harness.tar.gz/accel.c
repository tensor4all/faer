// Single-threaded Accelerate reference for tensor4all/faer#186.
// Build: cc -O2 -o accel accel.c -framework Accelerate
// Run:   ./accel <gemm_f64|gemm_c64|lu|cholesky|qr|gemv> <n> <reps>
#include <Accelerate/Accelerate.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <time.h>


static double now(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static void cpu(double *user, double *sys) {
  struct rusage ru;
  getrusage(RUSAGE_SELF, &ru);
  *user = (double)ru.ru_utime.tv_sec + 1e-6 * (double)ru.ru_utime.tv_usec;
  *sys = (double)ru.ru_stime.tv_sec + 1e-6 * (double)ru.ru_stime.tv_usec;
}

static unsigned long long state = 0x123456789abcdef1ULL;
static double rnd(void) {
  state ^= state >> 12;
  state ^= state << 25;
  state ^= state >> 27;
  unsigned long long v = state * 0x2545F4914F6CDD1DULL;
  return (double)(v >> 11) / 9007199254740992.0;
}

#define CAP(v, n) (v < n ? v : n)

int main(int argc, char **argv) {
  if (argc < 4) {
    fprintf(stderr, "usage: %s <family> <n> <reps>\n", argv[0]);
    return 2;
  }
  const char *family = argv[1];
  int n = atoi(argv[2]);
  int reps = atoi(argv[3]);
  double flops = 0.0;
  if (!strcmp(family, "gemm_f64")) flops = 2.0 * n * (double)n * n;
  else if (!strcmp(family, "gemm_c64")) flops = 8.0 * n * (double)n * n;
  else if (!strcmp(family, "lu")) flops = 2.0 / 3.0 * n * (double)n * n;
  else if (!strcmp(family, "cholesky")) flops = 1.0 / 3.0 * n * (double)n * n;
  else if (!strcmp(family, "qr")) flops = 4.0 / 3.0 * n * (double)n * n;
  else if (!strcmp(family, "gemv")) flops = (double)n * n;

  size_t nn = (size_t)n * (size_t)n;
  double *a = malloc(sizeof(double) * nn);
  double *b = malloc(sizeof(double) * nn);
  double *c = malloc(sizeof(double) * nn);
  double *x = malloc(sizeof(double) * n);
  double *y = malloc(sizeof(double) * n);
  int *ipiv = malloc(sizeof(int) * n);
  double *tau = malloc(sizeof(double) * n);
  for (size_t i = 0; i < nn; ++i) {
    a[i] = rnd() - 0.5;
    b[i] = rnd() - 0.5;
    c[i] = 0.0;
  }
  for (int i = 0; i < n; ++i) x[i] = rnd() - 0.5;

  int lwork = -1, info = 0;
  double wq = 0.0;
  if (!strcmp(family, "qr")) {
    dgeqrf_(&n, &n, a, &n, tau, &wq, &lwork, &info);
    lwork = (int)wq;
  }
  double *work = malloc(sizeof(double) * (lwork > 0 ? lwork : 1));

  int cholesky_setup = 0;
  if (!strcmp(family, "cholesky")) {
    // a := b*b^T + n*I in column-major (dsyrk would do, spelled out for clarity)
    cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, n, n, n, 1.0, b, n, b, n, 0.0, c,
                n);
    for (int i = 0; i < n; ++i) c[(size_t)i + (size_t)i * n] += (double)n;
    cholesky_setup = 1;
  }
  if (!strcmp(family, "gemm_c64")) {
    free(a);
    free(b);
    free(c);
    double *ca = malloc(sizeof(double) * 2 * nn);
    double *cb = malloc(sizeof(double) * 2 * nn);
    double *cc = malloc(sizeof(double) * 2 * nn);
    for (size_t i = 0; i < 2 * nn; ++i) {
      ca[i] = rnd() - 0.5;
      cb[i] = rnd() - 0.5;
      cc[i] = 0.0;
    }
    double alpha[2] = {1.0, 0.0}, beta[2] = {0.0, 0.0};
    a = ca;
    b = cb;
    c = cc;
  }

  double best = 1e300, best_u = 0.0, best_s = 0.0;
  for (int rep = 0; rep < reps; ++rep) {
    double u0, s0, u1, s1;
    cpu(&u0, &s0);
    double t0 = now();
    if (!strcmp(family, "gemm_f64")) {
      cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, n, n, n, 1.0, a, n, b, n, 0.0,
                  c, n);
    } else if (!strcmp(family, "gemm_c64")) {
      double alpha[2] = {1.0, 0.0}, beta[2] = {0.0, 0.0};
      cblas_zgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, n, n, n, alpha, a, n, b, n, beta,
                  c, n);
    } else if (!strcmp(family, "lu")) {
      memcpy(c, a, sizeof(double) * nn);
      dgetrf_(&n, &n, c, &n, ipiv, &info);
    } else if (!strcmp(family, "cholesky")) {
      memcpy(a, c, sizeof(double) * nn);
      char uplo = 'L';
      dpotrf_(&uplo, &n, a, &n, &info);
    } else if (!strcmp(family, "qr")) {
      memcpy(c, a, sizeof(double) * nn);
      dgeqrf_(&n, &n, c, &n, tau, work, &lwork, &info);
    } else if (!strcmp(family, "gemv")) {
      cblas_dgemv(CblasColMajor, CblasNoTrans, n, n, 1.0, a, n, x, 1, 0.0, y, 1);
    }
    double real = now() - t0;
    cpu(&u1, &s1);
    printf("rep %s n=%d i=%d real_ms=%.3f user_ms=%.3f sys_ms=%.3f rate=%.2f\n", family, n,
           rep, real * 1e3, (u1 - u0) * 1e3, (s1 - s0) * 1e3, flops / real / 1e9);
    if (real < best) {
      best = real;
      best_u = u1 - u0;
      best_s = s1 - s0;
    }
  }
  printf("best %s n=%d real_ms=%.3f user_ms=%.3f sys_ms=%.3f rate=%.2f\n", family, n,
         best * 1e3, best_u * 1e3, best_s * 1e3, flops / best / 1e9);
  (void)cholesky_setup;
  return 0;
}
