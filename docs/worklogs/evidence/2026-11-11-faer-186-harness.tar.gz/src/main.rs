// Measurement harness for tensor4all/faer#186: faer's own API, one family per
// process, best-of-N real time and the process' own user/sys time per repetition.
//
//   cargo run --release -- <family> <n> <threads> <reps>
//
// family: gemm_f64 | gemm_c64 | lu | cholesky | qr | gemv
// threads: 1 = Par::Seq, N>1 = faer::team::with_team(N, ..)
use dyn_stack::{MemBuffer, MemStack};
use faer::prelude::*;
use faer::{Accum, Par};
use std::time::Instant;

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> f64 {
        self.0 ^= self.0 >> 12;
        self.0 ^= self.0 << 25;
        self.0 ^= self.0 >> 27;
        let v = self.0.wrapping_mul(0x2545F4914F6CDD1D);
        ((v >> 11) as f64) / ((1u64 << 53) as f64)
    }
}

fn rusage() -> (f64, f64) {
    unsafe {
        let mut ru: libc::rusage = std::mem::zeroed();
        libc::getrusage(libc::RUSAGE_SELF, &mut ru);
        let u = ru.ru_utime.tv_sec as f64 + ru.ru_utime.tv_usec as f64 * 1e-6;
        let s = ru.ru_stime.tv_sec as f64 + ru.ru_stime.tv_usec as f64 * 1e-6;
        (u, s)
    }
}

/// Runs `f` `reps` times, printing one line per repetition and a best-of line.
/// `unit_flops` is the work of one call: GFLOP/s for a flop count, Gelem/s for a byte count.
fn bench(label: &str, n: usize, threads: usize, reps: usize, unit_flops: f64, mut f: impl FnMut()) {
    let mut best = f64::INFINITY;
    let mut best_pair = (0.0, 0.0);
    for rep in 0..reps {
        let (u0, s0) = rusage();
        let t0 = Instant::now();
        f();
        let real = t0.elapsed().as_secs_f64();
        let (u1, s1) = rusage();
        let (user, sys) = (u1 - u0, s1 - s0);
        println!(
            "rep {label} n={n} t={threads} i={rep} real_ms={:.3} user_ms={:.3} sys_ms={:.3} rate={:.2}",
            real * 1e3,
            user * 1e3,
            sys * 1e3,
            unit_flops / real / 1e9
        );
        if real < best {
            best = real;
            best_pair = (user, sys);
        }
    }
    println!(
        "best {label} n={n} t={threads} real_ms={:.3} user_ms={:.3} sys_ms={:.3} rate={:.2}",
        best * 1e3,
        best_pair.0 * 1e3,
        best_pair.1 * 1e3,
        unit_flops / best / 1e9
    );
}

fn run<F>(threads: usize, mut body: F)
where
    F: FnMut(Par<'_>),
{
    if threads <= 1 {
        body(Par::Seq);
    } else {
        faer::team::with_team(threads, |par| body(par));
    }
}

fn main() {
    let a: Vec<String> = std::env::args().collect();
    let family = a[1].clone();
    let n: usize = a[2].parse().unwrap();
    let threads: usize = a[3].parse().unwrap();
    let reps: usize = a.get(4).map(|s| s.parse().unwrap()).unwrap_or(3);
    let mut rng = Rng(0x1234_5678_9abc_def1);

    match family.as_str() {
        "gemm_f64" | "gemm_c64" => {
            let flops = (if family == "gemm_c64" { 8.0 } else { 2.0 }) * (n as f64).powi(3);
            run(threads, |mut par| {
                if family == "gemm_f64" {
                    let lhs = Mat::<f64>::from_fn(n, n, |_, _| rng.next() - 0.5);
                    let rhs = Mat::<f64>::from_fn(n, n, |_, _| rng.next() - 0.5);
                    let mut dst = Mat::<f64>::zeros(n, n);
                    bench(&family, n, threads, reps, flops, || {
                        faer::linalg::matmul::matmul(
                            dst.as_mut(),
                            Accum::Replace,
                            lhs.as_ref(),
                            rhs.as_ref(),
                            1.0f64,
                            par.reborrow(),
                        );
                    });
                } else {
                    let lhs = Mat::<c64>::from_fn(n, n, |_, _| {
                        c64::new(rng.next() - 0.5, rng.next() - 0.5)
                    });
                    let rhs = Mat::<c64>::from_fn(n, n, |_, _| {
                        c64::new(rng.next() - 0.5, rng.next() - 0.5)
                    });
                    let mut dst = Mat::<c64>::zeros(n, n);
                    bench(&family, n, threads, reps, flops, || {
                        faer::linalg::matmul::matmul(
                            dst.as_mut(),
                            Accum::Replace,
                            lhs.as_ref(),
                            rhs.as_ref(),
                            c64::new(1.0, 0.0),
                            par.reborrow(),
                        );
                    });
                }
            });
        }
        "lu" => {
            let flops = 2.0 / 3.0 * (n as f64).powi(3);
            let a = Mat::<f64>::from_fn(n, n, |_, _| rng.next() - 0.5);
            let mut lu = Mat::<f64>::zeros(n, n);
            let mut perm = vec![0usize; n];
            let mut perm_inv = vec![0usize; n];
            run(threads, |mut par| {
                let params = Default::default();
                let mut mem = MemBuffer::new(
                    faer::linalg::lu::partial_pivoting::factor::lu_in_place_scratch::<usize, f64>(
                        n,
                        n,
                        par.shape(),
                        params,
                    ),
                );
                let stack = MemStack::new(&mut mem);
                bench("lu", n, threads, reps, flops, || {
                    lu.copy_from(&a);
                    faer::linalg::lu::partial_pivoting::factor::lu_in_place(
                        lu.as_mut(),
                        &mut perm,
                        &mut perm_inv,
                        par.reborrow(),
                        stack,
                        params,
                    );
                });
            });
        }
        "cholesky" => {
            let flops = 1.0 / 3.0 * (n as f64).powi(3);
            let b = Mat::<f64>::from_fn(n, n, |_, _| rng.next() - 0.5);
            let mut spd = Mat::<f64>::zeros(n, n);
            faer::linalg::matmul::matmul(
                spd.as_mut(),
                Accum::Replace,
                b.as_ref(),
                b.transpose(),
                1.0f64,
                Par::Seq,
            );
            for i in 0..n {
                spd[(i, i)] += n as f64;
            }
            let mut l = Mat::<f64>::zeros(n, n);
            run(threads, |mut par| {
                let params = Default::default();
                let mut mem = MemBuffer::new(
                    faer::linalg::cholesky::llt::factor::cholesky_in_place_scratch::<f64>(
                        n,
                        par.shape(),
                        params,
                    ),
                );
                let stack = MemStack::new(&mut mem);
                bench("cholesky", n, threads, reps, flops, || {
                    l.copy_from(&spd);
                    faer::linalg::cholesky::llt::factor::cholesky_in_place(
                        l.as_mut(),
                        Default::default(),
                        par.reborrow(),
                        stack,
                        params,
                    )
                    .unwrap();
                });
            });
        }
        "qr" => {
            let flops = 4.0 / 3.0 * (n as f64).powi(3);
            let a = Mat::<f64>::from_fn(n, n, |_, _| rng.next() - 0.5);
            let mut qr = Mat::<f64>::zeros(n, n);
            let block_size =
                faer::linalg::qr::no_pivoting::factor::recommended_block_size::<f64>(n, n);
            let mut q = Mat::<f64>::zeros(block_size, Ord::min(n, n));
            run(threads, |mut par| {
                let params = Default::default();
                let mut mem = MemBuffer::new(
                    faer::linalg::qr::no_pivoting::factor::qr_in_place_scratch::<f64>(
                        n,
                        n,
                        block_size,
                        par.shape(),
                        params,
                    ),
                );
                let stack = MemStack::new(&mut mem);
                bench("qr", n, threads, reps, flops, || {
                    qr.copy_from(&a);
                    faer::linalg::qr::no_pivoting::factor::qr_in_place(
                        qr.as_mut(),
                        q.as_mut(),
                        par.reborrow(),
                        stack,
                        params,
                    );
                });
            });
        }
        "gemv" => {
            let elems = (n as f64) * (n as f64);
            let a = Mat::<f64>::from_fn(n, n, |_, _| rng.next() - 0.5);
            let x = Mat::<f64>::from_fn(n, 1, |_, _| rng.next() - 0.5);
            let mut y = Mat::<f64>::zeros(n, 1);
            run(threads, |mut par| {
                bench("gemv", n, threads, reps, elems, || {
                    faer::linalg::matmul::matmul(
                        y.as_mut(),
                        Accum::Replace,
                        a.as_ref(),
                        x.as_ref(),
                        1.0f64,
                        par.reborrow(),
                    );
                });
            });
        }
        other => panic!("unknown family {other}"),
    }
}
