faer#173 quiet-host campaign on evo (AMD Ryzen AI 9 HX 470), tree tensor4all/faer 2c2bfad1.

topology.json          host facts read from sysfs/procfs before the first run
binaries.sha256        sha256 of the two probe binaries and the Fortran reference
harness/               the probe crate and the driver; nothing in it lives in the repo
run/summary.json       per-cell medians, session medians, spread, lanes
run/samples.csv        per-run records including guard attempts and load1
run/s*.stdout          every run's JSON result (value, samples, runtime lane)
run/s*.stderr          every run's pinned.sh guard log ("idle before and after")
logs/                  build, test, table and process-check logs

Protocol: 2 sessions x (3 warmups + 10 single-call samples) per cell; observer pinned to
0-3,12-15 (the 16 MiB L3 domain); measured set 4-11,16-23 (the 8 MiB domain, 8 cores,
16 hardware threads); one measurement at a time under ~/.bench_slot; 180 runs, 0 rejections.
