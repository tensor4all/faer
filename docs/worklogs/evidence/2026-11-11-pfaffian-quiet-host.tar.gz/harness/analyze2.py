#!/usr/bin/env python3
"""faer#173 HEAD (2c2bfad1) tables: Seq vs Team 4/8/16, default vs x86-v4."""
import json, statistics, sys
from pathlib import Path

run = Path(sys.argv[1]) if len(sys.argv) > 1 else sorted(Path('.').glob('run-*'))[-1]
data = json.loads((run / 'summary.json').read_text())
idx = {(c['n'], c['dtype'], c['arm'], c['width']): c for c in data['cells']}
SIZES, DTYPES = [64, 128, 256, 512, 1024], ['f64', 'c64']

def ms(n, d, arm, w):
    c = idx.get((n, d, arm, w))
    return c['median_s'] * 1e3 if c else None

def samples(n, d, arm, w):
    c = idx.get((n, d, arm, w))
    return c['session_medians_s'] if c else []

print(f"cells={len(data['cells'])} rejected={len(data['rejected'])} tree={data.get('tree')}")
print(f"observer={data['observer_cpus']} measured={data['measured_cpus']}")
print('lanes:', {c['arm']: c['lanes'] for c in data['cells'] if c['width'] == 1})

for build, arm in (('default', 'faer-default'), ('x86-v4', 'faer-x86-v4')):
    print(f"\n### {build}\n")
    print('| n | dtype | Fortran 1T | Seq | T4 | T8 | T16 | Seq/F | T4/Seq | T8/Seq | T16/Seq | F/T8 |')
    print('|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|')
    for n in SIZES:
        for d in DTYPES:
            f, s = ms(n, d, 'fortran', 1), ms(n, d, arm, 1)
            t4, t8, t16 = ms(n, d, arm, 4), ms(n, d, arm, 8), ms(n, d, arm, 16)
            print(f'| {n} | {d} | {f:.4f} | {s:.4f} | {t4:.4f} | {t8:.4f} | {t16:.4f} | '
                  f'{s/f:.3f} | {s/t4:.3f} | {s/t8:.3f} | {s/t16:.3f} | {f/t8:.2f} |')

print('\n### x86-v4 vs default (same cell)\n')
print('| n | dtype | Seq v3 | Seq v4 | v3/v4 | T8 v3 | T8 v4 | T8 v3/v4 | T16 v3 | T16 v4 | T16 v3/v4 |')
print('|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|')
for n in SIZES:
    for d in DTYPES:
        row = [ms(n, d, 'faer-default', w) for w in (1, 8, 16)] + [ms(n, d, 'faer-x86-v4', w) for w in (1, 8, 16)]
        s3, t83, t163, s4, t84, t164 = row
        print(f'| {n} | {d} | {s3:.4f} | {s4:.4f} | {s3/s4:.3f} | {t83:.4f} | {t84:.4f} | {t83/t84:.3f} | '
              f'{t163:.4f} | {t164:.4f} | {t163/t164:.3f} |')

print('\n### best measured 1T / T8 (4x gate, same window)\n')
print('| n | dtype | best 1T ms | build | T8 ms | best1T/T8 |')
print('|---:|---|---:|---|---:|---:|')
gate = {}
for n in SIZES:
    for d in DTYPES:
        for arm, build in (('faer-default', 'default'), ('faer-x86-v4', 'x86-v4')):
            ones = [('fortran', ms(n, d, 'fortran', 1)), (build + '-Seq', ms(n, d, arm, 1))]
            best = min(ones, key=lambda kv: kv[1])
            print(f'| {n} | {d} | {best[1]:.4f} | {best[0]} | {ms(n, d, arm, 8):.4f} | {best[1]/ms(n,d,arm,8):.2f} |')
            gate[(n, d, build)] = best[1] / ms(n, d, arm, 8)

print('\n### session medians (spread = (max-min)/median)\n')
print('| n | dtype | arm | w | s1 | s2 | spread % |')
print('|---:|---|---|---:|---:|---:|---:|')
worst = sorted([c for c in data['cells']], key=lambda c: -c['spread_pct'])
for c in worst[:12]:
    s = c['session_medians_s']
    print(f"| {c['n']} | {c['dtype']} | {c['arm']} | {c['width']} | {s[0]*1e3:.4f} | {s[1]*1e3:.4f} | {c['spread_pct']:.2f} |")
print('max spread over all cells: %.2f%%' % worst[0]['spread_pct'])

# value agreement
import glob
vals = {}
for f in glob.glob(str(run / '*.stdout')):
    d = json.loads(Path(f).read_text())
    name = Path(f).name.split('-', 1)[1].rsplit('-', 1)[0]
    arm = 'fortran' if 'fortran' in name else ('v4' if 'x86-v4' in name else 'v3')
    key = (d['n'], d['dtype'])
    vals.setdefault(key, {}).setdefault(arm, []).append(complex(d['pf_re'], d['pf_im']))
def reldiff(a, b):
    return abs(a - b) / abs(a) if a != 0 else abs(b)
worst_vf = worst_34 = 0.0
for k, v in vals.items():
    f = v['fortran'][0]
    own = v['v3'] + v['v4']
    for x in own:
        worst_vf = max(worst_vf, reldiff(f, x))
    worst_34 = max(worst_34, max(reldiff(x, y) for x in v['v3'] for y in v['v4']))
print(f'\nmax |faer - fortran| / |fortran| over all n, dtypes, widths, both builds: {worst_vf:.3e}')
print(f'max |v3 - v4| / |v3| over the same cells: {worst_34:.3e}')
