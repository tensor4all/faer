#!/usr/bin/env python3
"""faer#173 quiet-host campaign on evo, re-measured at main 2c2bfad1: Seq vs Team 4/8/16,
default vs x86-v4, with the 1-thread Fortran PFAPACK arm in the same window.

One measurement at a time, every cell idle-guarded by the harness's pinned.sh
(3 s idle window, 5% busy, 3 attempts), observer pinned outside the measured L3
domain, arms rotated per session so no arm owns a time of day. Rejected attempts
are archived by the guard, counted here, and never retried by the campaign.
"""
import argparse
import csv
import fcntl
import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
GUARD = Path.home() / 'projects/tensor4all/faer-benchmark/benchmarks/scripts/pinned.sh'
SLOT = Path.home() / '.bench_slot'
# the larger L3 domain: 8 cores, 16 hardware threads
MEASURED_L3 = set(range(4, 12)) | set(range(16, 24))
CPUS = {1: '4', 4: '4-7', 8: '4-11', 16: '4-11,16-23'}
BIN = HERE / 'bin'
INPUTS = HERE / 'inputs'


def run_cell(arm, kind, binary, n, dtype, width, out, tag, env):
    matrix = INPUTS / f'n{n}-{dtype}.bin'
    cmd = [str(binary), str(matrix), str(n), dtype] + ([] if kind in ('fortran', 'mvmc') else [str(width)])
    with (out / (tag + '.stderr')).open('w') as err:
        proc = subprocess.run(['bash', str(GUARD), CPUS[width], '--', *cmd],
                              env=env, text=True, stdout=subprocess.PIPE, stderr=err)
    (out / (tag + '.stdout')).write_text(proc.stdout)
    guard_log = (out / (tag + '.stderr')).read_text()
    return proc.returncode, guard_log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--sessions', type=int, default=3)
    ap.add_argument('--cells', default='64:f64,64:c64,128:f64,128:c64,256:f64,256:c64,'
                                      '512:f64,512:c64,1024:f64,1024:c64')
    ap.add_argument('--arms', default='fortran=fortran-runner:fortran:1;'
                                      'faer-default=faer-default-head:faer:1,4,8,16;'
                                      'faer-x86-v4=faer-x86-v4-head:faer:1,4,8,16')
    args = ap.parse_args()

    cells = [c.split(':') for c in args.cells.split(',')]
    schedule = []
    for spec in args.arms.split(';'):
        name, rest = spec.split('=')
        binary, kind, widths = rest.split(':')
        for w in [int(x) for x in widths.split(',')]:
            schedule.append((name, Path(BIN / binary), kind, w))
    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=False)

    boost = Path('/sys/devices/system/cpu/cpufreq/boost')
    assert boost.read_text().strip() == '0', 'boost must be off'
    assert 'AMD Ryzen AI 9 HX 470' in Path('/proc/cpuinfo').read_text(), 'wrong host'
    affinity = set(os.sched_getaffinity(0))
    assert not affinity & MEASURED_L3, f'observer {sorted(affinity)} overlaps measured L3 {sorted(MEASURED_L3)}'

    env = dict(os.environ)
    env.pop('CARGO_TARGET_DIR', None)
    env['TMPDIR'] = str(out / 'pinned-tmp')
    Path(env['TMPDIR']).mkdir(exist_ok=True)
    env['PINNED_CSV'] = str(out / 'pinned.csv')
    (out / 'pinned.csv').write_text('')
    for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
        env[k] = '1'

    slot = SLOT.open('a+')
    fcntl.flock(slot, fcntl.LOCK_EX)
    rows, rejected = [], []
    started = time.time()
    try:
        with (out / 'samples.csv').open('w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=[
                'session', 'n', 'dtype', 'arm', 'width', 'median_seconds', 'samples_seconds',
                'load1_before', 'load1_after', 'guard_attempts', 'guard_rejections', 'status',
                'runtime_lane', 'f64_lanes'])
            writer.writeheader()
            for session in range(1, args.sessions + 1):
                for n, dtype in cells:
                    shift = (session - 1) * 3 % len(schedule)
                    order = schedule[shift:] + schedule[:shift]
                    for arm, binary, kind, width in order:
                        tag = f's{session}-n{n}-{dtype}-{arm}-{width}'
                        before = os.getloadavg()
                        t0 = time.monotonic()
                        rc, guard_log = run_cell(arm, kind, binary, n, dtype, width, out, tag, env)
                        after = os.getloadavg()
                        attempts = guard_log.count('attempt')
                        rejections = guard_log.count('rejecting it') + guard_log.count('busy before run')
                        row = {'session': session, 'n': n, 'dtype': dtype, 'arm': arm, 'width': width,
                               'load1_before': f'{before[0]:.2f}', 'load1_after': f'{after[0]:.2f}',
                               'guard_attempts': attempts, 'guard_rejections': rejections,
                               'median_seconds': '', 'samples_seconds': '', 'status': 'accepted'}
                        if rc != 0:
                            row['status'] = f'rejected-rc{rc}'
                            rejected.append({'tag': tag, 'rc': rc, 'guard': guard_log.strip()[-1500:]})
                        else:
                            result = json.loads((out / (tag + '.stdout')).read_text())
                            row['median_seconds'] = result['median_seconds']
                            row['samples_seconds'] = json.dumps(result['samples_seconds'])
                            row['runtime_lane'] = result.get('runtime_lane', '')
                            row['f64_lanes'] = result.get('f64_lanes', '')
                        rows.append(row)
                        writer.writerow(row)
                        csvfile.flush()
                        shown = 'REJECTED' if row['median_seconds'] == '' else f"{row['median_seconds']*1e3:.4f} ms"
                        print(f'{tag} {shown} {time.monotonic()-t0:.0f}s rej={rejections}', flush=True)
    finally:
        summary = []
        for n, dtype in cells:
            for arm, _, _, width in schedule:
                vals = [r for r in rows if (r['n'], r['dtype'], r['arm'], r['width']) == (n, dtype, arm, width)
                        and r['median_seconds'] != '']
                if not vals:
                    continue
                xs = sorted(float(r['median_seconds']) for r in vals)
                summary.append({'n': int(n), 'dtype': dtype, 'arm': arm, 'width': width,
                                'sessions': len(xs), 'median_s': statistics.median(xs),
                                'min_s': xs[0], 'max_s': xs[-1],
                                'spread_pct': 0.0 if len(xs) == 1 else 100 * (xs[-1] - xs[0]) / statistics.median(xs),
                                'session_medians_s': xs,
                                'lanes': sorted({(r.get('runtime_lane', ''), r.get('f64_lanes', '')) for r in vals})})
        (out / 'summary.json').write_text(json.dumps({
            'host': 'evo (AMD Ryzen AI 9 HX 470, 24 online CPUs, 12 cores, 2 L3 domains)',
            'tree': 'tensor4all/faer 2c2bfad14cfbf19399f30da80ed7741bb3c8206c',
            'measured_cpus': '4-11,16-23 (one L3 domain, 8 cores, 16 hardware threads)',
            'observer_cpus': sorted(affinity),
            'protocol': '3 sessions x (3 warmups + 10 single-call samples); median; idle guard 3s/5% before+after; one measurement at a time',
            'started': started, 'finished': time.time(),
            'schedule': [list(x) for x in [(a, k, w) for a, _, k, w in schedule]],
            'rejected': rejected, 'cells': summary}, indent=2, default=str) + '\n')
        with (out / 'summary.csv').open('w', newline='') as f:
            if summary:
                w = csv.DictWriter(f, fieldnames=[k for k in summary[0] if k != 'session_medians_s' and k != 'lanes'])
                w.writeheader()
                for r in summary:
                    w.writerow({k: v for k, v in r.items() if k in w.fieldnames})
        fcntl.flock(slot, fcntl.LOCK_UN)


if __name__ == '__main__':
    main()
